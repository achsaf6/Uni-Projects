
public class TestException extends Exception {
	public TestException(String arg0) {
		super(arg0);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
