package oop.ex6.main;

public class TooManyScopeClosersException extends IllegalCodeException {

    public TooManyScopeClosersException(String message) {
        super(message);
    }
}
