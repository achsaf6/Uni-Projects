package oop.ex6.main;

public class IllegalCodeException extends Exception{
    public IllegalCodeException(String message) {
        super(message);
    }
}
